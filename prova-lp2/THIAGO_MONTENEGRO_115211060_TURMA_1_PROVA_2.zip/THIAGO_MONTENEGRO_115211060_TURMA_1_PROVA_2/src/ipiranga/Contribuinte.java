package ipiranga;

public abstract class Contribuinte implements Comparable<Contribuinte>{

	private String nome;
	private String cpf;
	private int bensAcumulados;
	
	public Contribuinte(String nome, String cpf) throws Exception{
		if(nome == null || nome.trim().isEmpty()){
			throw new Exception("O nome do contribuinte não pode ser nulo ou vazio");
		}
		if(cpf == null || cpf.trim().isEmpty()){
			throw new Exception("O cpf não pode ser nulo ou vazio");
		}
		
		this.nome = nome;
		this.cpf = cpf;
		this.bensAcumulados = 0;
	}
	
	public abstract double calculaTributacao();
	
	public abstract boolean sinalRiqueza();

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	@Override
	public String toString(){
		return " " + nome + ", " + cpf +".";
	}
	
	public int CompareTo(Contribuinte outroContribuinte){
		if(calculaTributacao() > outroContribuinte.calculaTributacao()){
			return 1;
		}
		if(calculaTributacao() < outroContribuinte.calculaTributacao()){
			return -1;
		}
		return 0;
	}

	public int getBensAcumulados() {
		return bensAcumulados;
	}

	public void setBensAcumulados(int bensAcumulados) {
		this.bensAcumulados = bensAcumulados;
	}

}
